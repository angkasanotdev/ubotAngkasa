
```
apt update && apt upgrade -y
```
```
git clone https://github.com/AlwaysBoyszz/UbotVerr
```
```
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
```
```
cd Verr && screen -S Verr
```
```
bash installnode.sh && sudo apt install python3.12-venv
```
```
python3 -m venv Verr && source Verr/bin/activate
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env && nano .env
```
```
python3 -m PyroUbot
```


PENTING !!!!!
KALAU ADA EROR SEMACAM UGLIFY = PERGI KE CHATGPT TANYA CARA INSATLL UGLIFY NANTI AMBBIL COMMANDNYA BIASANYA NPM INSATLL UGLIFY 
TERUS SETELAHNYA RUN ULANG PYTHON3 -M PYROUBOT YANG DI ATAS