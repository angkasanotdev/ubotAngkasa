from PyroUbot import *

MODULE = "ᴛǫᴛᴏ"
HELP = """
{bot.me.mention}

⎆ Special Thanks:
ᚗ Ryt (Gua Selaku Own)
ᚗ All Buyyer Ubot
ᚗ Teman-teman yang selalu support dan buyer-buyer ku
"""
