```
apt update && apt upgrade -y
```
```
apt install python3 python3-pip git unzip -y
```
```
wget https://github.com/angkasanotdev/ubotAngkasa/raw/main/ubotangkasa.zip
```
```
unzip ubotangkasa.zip
```
```
cd ubotangkasa
```
```
pip install -r requirements.txt
```
```
cp sample.env .env
```
```
nano .env
```
```
CTRL + C
```
```
bash start.sh
```
```
apt install screen -y
```
```
screen -S angkasaUbot
```
```
cd ~/angkasaUbot UVLOOP_NO_EXTENSIONS=1 bash start.sh
```
```
CTRL + A LALU D
```